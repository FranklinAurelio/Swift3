/* BOOLEANS AND CONDITIONALS */
var name: String = "Franklin"
var verification : Bool = false

if verification{
    print("\(name) ja foi verificado")
}
if verification == false {
    print("\(name) teve a verificacao negada")
}

//condicionais com comparacao
var id: Int = 123445
var idVerification: Int = 123447

if id == idVerification {
    verification = true
}
if verification == true {
    print("acesso permitido")
}
else{
    print("acesso negado")
}

// and e or
if (name == "Franklin" && id == idVerification) || (verification == true){
    print("acesso permitido")
}

//else if
if verification == true{
    print("acesso permitido")
}
else if verification == false && name == "Franklin"{
    print("usuario reconhecido, faca a verificacao")
}
else if verification == false && id == idVerification{
    print("id correto, atualize seus dados cadastrais")
}
else{
    print("acesso negado")
}

/* SWITCH */
switch id {
case idVerification:
    print("id correto")
case 123445:
    print("id desatualizado")
default:
    print("acesso negado")
}

// operadores de intervalo
// ... operador ate podendo variar ..<
var max: Int = 150
switch max {
case 0...100:
    print("o valor esta entre 0 e 100")
case 101...200:
    print("o valor esta entre 101 e 200")
default:
    print("o valor e maior que 200")
}
