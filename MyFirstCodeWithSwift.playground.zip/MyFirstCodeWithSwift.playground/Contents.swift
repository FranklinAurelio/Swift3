//criacao de variaveis
var name = "franklin"
var age = 21

// criacao de constantes
let gravity = 10

//para concatenar, usa-se o +
print(name, "tem", age, "anos")

// interpolacao
print("\(name) tem \(age) anos")
print("A gravidade é: \(age * gravity)")

//conversao de int para string
// TIPO_DE_DADO(variavel a ser convertida)
/*
 No caso particular de transformacao de string para numero é necessario usar o operador '!'
 var nome: String = "123"
 Int(nome)!
 */
print("a gravidade é:" + " " +  String(gravity))

/* DATA TYPES*/
/*
 Int -> inteiros
 String -> cadeia de caracteres
 Float ->  decimais
 Double -> decimais longos
 */
var pi: Float = 3.14
print("O valor de pi é: \(pi)")

/* OPERACOES BASICAS */

/*
 OPERADORES ARITIMETICOS
 +, -, *, /
 
 OPERADOR MODULO
 %
 
 OPERANDO E ASSINALANDO
 +=, -=, *=, /=
 
 */

/* ARRAYS */

//Forma implicita
var yearImplicita = [1999, 2000, 2001, 2002]

//Forma Explicita
var year: [Int] = [1999, 2000, 2001, 2002]

//Adicionar item
year.append(2003)

//metodo Count
year.count
print("O array year tem \(year.count) elementos")

//manipulacao de array
year.first
print("O primeiro elemento de year é: \(String(year.first!))")

year.last
print("O ultimo elemento de year é: \(String(year.last!))")

year[1]
print("O segundo elemento de year é: \(year[1])")

//outra forma de acessar o ultimo elemento da lista é usando o metodo Count
year[year.count-1]
print("O ultimo elemento de year é: \(year[year.count-1])")

//alterar o valor de uma posicao do array
year[2] = 1998
print("Os elementos \(year) pertencem ao array year")

//inserir e remover elementos de um array
//para inserir em posiscoes diferentes da ultima como no metodo .append pode se usar o metodo insert
year.insert(2001, at: 2)
//onde os parametros sao os valores e o index onde eu quero que seja adicionado

//para remover usa se o metodo remove, onde passamos o index por parametro
year.remove(at: 1)
print("Os elementos \(year) sao os novos elementos do array")

//para saber se meu array contem um elemento especifico posso usar o metodo .contains que me retorna um bool
year.contains(2002)

//para descobrir o index de um determinado elemento existente em um array pode se usar o metodo firstIndex

year.firstIndex(of: 2002)



