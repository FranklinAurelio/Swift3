/* LOOPS */
// for
var array: [Int] = []
var strArray: [String] = ["franklin", "julia", "yoda"]

var i: Int = 0
var j: Int = 0
var k: Int = 0
var m: Int = 0


for _ in 1...10 {
    array.append(i)
    i+=1
}
print("O elementos do array sao: \(array)")

array.insert(10, at: 10)
array.insert(11, at: 11)
array.remove(at: 10)
print("Esses sao os novos elementos do array: \(array)")

//outra maneira de fazer
for j in 1 ..< 12 {
    print("O valor de j é: \(j)")
}

//Eu posso fazer o for sem necessariamente declarar  a variavel anteriormente
for name in strArray {
    print("O nome é: \(name)")
}

//while
while k <= 10 {
    print("O valor de k é: \(k)")
    k += 1
}

//repeat while
repeat{
    print("O valor de k é: \(m)")
    m += 1
}while m < 11

/* FUNCTION */

func sub (num:Int){
    if num > 10 {
      print("A diferenca é: \(num - 10)")
    }
    else{
        print("O que faltava era: \(10 - num)")
    }
}

sub(num: 34)
sub(num: -4)

//function with return

func sum(numb1:Float, numb2:Int) -> Float{
    //aqui usei tipod de dados diferentes para a operacao, entao tive que converte-los para o mesmo tipo
    return (numb1 + Float(numb2))
}
var soma:Float = sum(numb1: 44.5, numb2: 456)
print("O valor da soma é: \(soma)")

/* TUPLAS */

var data = ("Franklin", 21, 1.96, "IT")
print("\(data.0) tem \(data.1) anos, \(data.2)m de altura e cursa \(data.3)")

var datas = (nome:"franklin", idade:21, curso: "engenharia da computacao", gradunado: true)
print("\(datas.nome) tem \(datas.idade) anos, cursa \(datas.curso), graduando: \(datas.gradunado)")

//tuplas explicitas
var numbs: (numb1: Int, numb2: Float, numb3: Double)
numbs = (12, 13.4, 6.4443)

func sumOfTuple(tuple:(numb1: Int, numb2: Float, numb3: Double)) -> Int{
    return tuple.numb1 + Int(tuple.numb2) + Int(tuple.numb3)
}

var somaDeTupla: Int = sumOfTuple(tuple: numbs)
print("O valor da soma das tuplas é: \(somaDeTupla)")

/* OPITIONALS */

var age:Int? = 21
var character: String? = "character"

print(age as Any)

if age != nil{
    print("not null")
}
else{
    print("null")
}
// a exclamacao indica que o valor realmente existe
print(age!)
print(character as Any)
character?.uppercased()

//optional binding
//if let
if let characters = character{
    print(characters)
    characters.uppercased()
}


