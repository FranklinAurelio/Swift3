/* CLASS */

class FirstClass{
    var color: String = ""
    var hight:Float? = nil
    var pernas:Int = 0
    var width:Float = 0
    var comprimento:Float = 0
    
    //propriedades computadas
    var area:Float{
        var areaCalc: Float = (width*comprimento)
        return areaCalc
    }
    
    //funcao na classe
    func volume(areaRes:Float, hightRes:Float) -> Float {
        var volumeClac:Float = (areaRes * hightRes)
        return volumeClac
    }
}

var callClass1 = FirstClass()
callClass1.color = "blue"
callClass1.hight = 1.3
callClass1.pernas = 10
callClass1.width = 3.0
callClass1.comprimento = 5.0
callClass1.area
var vloume1: Float = callClass1.volume(areaRes: callClass1.area, hightRes: callClass1.hight!)

var callClass2 = FirstClass()
callClass2.color = "black"
callClass2.hight = 0.9
callClass2.pernas = 4
callClass2.width = 1.5
callClass2.comprimento = 2.0
callClass2.area
var vloume2: Float = callClass2.volume(areaRes: callClass2.area, hightRes: callClass2.hight!)


var callClass: [FirstClass] = [callClass1, callClass2]

for  i in callClass{
    print("A classe  do array tem dimensoes \(i.width) x \(i.hight!) x \(i.comprimento)")
    print("A classe  do array tem area \(i.area) ")
}
print("A classe 0 do array tem area \(vloume1) e a classe 1 \(vloume2) ")

class SecondClass{
    var marca:String = ""
    var modelo:String = ""
    var velocidade:Int? = nil
    
    //inicializador
    init() {
        print("Criando objeto SecondClass...")
    }
    init(marca:String, modeloDoCarro:String, velocidadeDoCarro:Int?) {
        print("Criando objeto SecondClass personalizado...")
        //usa se o metodo self quando o paramentro da classe e a variavel fora dela possuem o mesmo nome, self indentifica quem é a classe
        self.marca = marca
        modelo = modeloDoCarro
        velocidade = velocidadeDoCarro
    }
    
}

var car = SecondClass()
var tesla = SecondClass(marca: "tesla", modeloDoCarro: "model13", velocidadeDoCarro: 300)
print("O carro da marca \(tesla.marca) modelo \(tesla.modelo) possui velocidae de \(tesla.velocidade!)Km/h")

/* STRUCTS */
// structs sao muito semelhantes a classes em sua implemtentacao o que muda basicamente sao questoes de otimizacao
/*
 - Structs sao mais rapidas que classes
 - Classes usam ponteiros para se referir a memoria, ous seja posso fazer dois objetos apontarem para o mesmo enderece
 - Structs nao guardan referencias por isso tornam se mais otimozdas
 
 */

/* ENUMS */
//enums sao varuaveis seletoras assim como booleans, no entanto pode apresentar mais de uma opcao

//nesse caso nosso enum seria como se fosse um boolean de quatro valores
enum pontosCardeais{
    
    case Norte
    case Sul
    case Lest
    case Oest
}

var directions = pontosCardeais.Lest

if directions == .Lest{
    print("leste")
}
else
    if directions == .Oest{
    print("oeste")
}

//rawValues and HashValues

enum daysOfWeek : String{
    
    case Seg = "segunda"
    case Ter = "terca"
    case Qua = "quarta"
    case Qui = "quinta"
    case Sex = "sexta"
    case Sab = "sabado"
    case Dom = "domingo"
}
var days = daysOfWeek.Qua

if days == .Qua{
    print("\(days.rawValue)")
}
else
if days == .Sex{
    print("\(days.rawValue)")
}

//caso nao queiramos ter o valor do enum, podemos usar outra propriedade, o hashValue que retorna o indice

if days == .Qua{
    print("\(days.hashValue)")
}
else
if days == .Sex{
    print("\(days.hashValue)")
}

//EXEMPLO DE APLICACAO
enum orientacao:String{
    case Canhota = "canhoto"
    case Destro = "destro"
    case Ambi = "ambidestro"
}

enum natural: String{
    case Maranhao = "maranhense"
    case SaoPaulo = "paulista"
    case Parana = "paranaense"
}
class Brasileiro{
    var nome:String = "jaime"
    var orientacaoMotora = orientacao.Ambi
    var naturalidade = natural.Maranhao
    
    func retornarInfo(name:String, orientation:orientacao, natura:natural) -> String {
        var infos:String = ("\(name) naturalizado \(natura.rawValue) possui orientacao motora \(orientation.rawValue)")
        return infos
    }
}

var informationsClass = Brasileiro()
var information:String = informationsClass.retornarInfo(name: informationsClass.nome, orientation: informationsClass.orientacaoMotora, natura: informationsClass.naturalidade)

print(information)

//Herancas
    //subclasses / override / Super / Final

class Cel{
    var name:String = ""
    var idade:Int = 0
    func descrition()->String {
        return "It's the class Cel"
    }
}

//a classe tecido esta herdando as propriedades de Cel
class Tecido: Cel{
    var quantidadeCel: Int = 0
    //overrride sobrescreve dados
    override func descrition()->String{
        return "It's the class Tecido"
    }
}

class Orgao: Tecido{
    var tam: Float = 0
    //final significa que a funcao nao pode ser mais alterada ou sobreposta esse sera o valor final dela
     final override func descrition()->String{
        //super retorna a hierarquia superior da classe
        return " a classe superiro a orgao é \(super.descrition())"
    }
}

//bio é um objeto criado a partir de uma subclasse
var Bio = Tecido()
Bio.quantidadeCel = 20000
Bio.idade = 3
Bio.name = "neuronio"

var orgao = Orgao()
orgao.tam = 0.8
orgao.quantidadeCel = 80000
orgao.name = "coracao"
orgao.idade = 4

print(orgao.descrition())


